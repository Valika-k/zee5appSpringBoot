package com.zee.zee5app.service;

import com.zee.zee5app.dto.Role;

public interface RoleService {

	public String addRole(Role role);
	
	public void deleteRole(int roleId);
}
