package com.zee.zee5app.exception;

public class InvalidAmountException extends Exception {
	public InvalidAmountException(String message) {
		super(message);

}
}