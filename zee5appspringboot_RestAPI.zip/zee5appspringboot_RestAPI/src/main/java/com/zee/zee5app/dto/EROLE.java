package com.zee.zee5app.dto;

public enum EROLE {
	ROLE_USER,
	ROLE_ADMIN;
	
}
