package com.zee.zee5app.dto;

public class Person {

}
