package com.zee.zee5app.exception;

public class AlreadyExistsException extends Exception {
	public AlreadyExistsException(String message) {
		super(message);

}
}