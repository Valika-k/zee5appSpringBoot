package com.zee.zee5app.exception;

public class NameNotFoundEception extends Exception {
	public NameNotFoundEception(String message) {
		super(message);

}
}